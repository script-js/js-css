const internal_pages = {
    // YOU MUST ADD YOUR INTERNAL PAGE TO THIS FILE IF YOU WANT IT TO WORK!
    // This index is how HT can reference what page to what file
    newtab: "newwin.html",
    // extensionsmarketplace: "Hypertabs/internal/extensions/marketplace.html",
    // extensions: "Hypertabs/internal/extensions/index.html",
    // games: "Hypertabs/internal/g/index.html"
}
